#include "Input.h"
#include <iostream>
#include <conio.h>

char getInstantaneousCharInput() {
	char input = _getch();
	return input;
}