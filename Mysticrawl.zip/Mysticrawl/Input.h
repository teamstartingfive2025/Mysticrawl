#pragma once

char getInstantaneousCharInput(); // Gets a single character input from the user without requiring Enter key press